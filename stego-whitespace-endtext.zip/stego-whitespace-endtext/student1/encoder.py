def text_to_binary(text):
    return ''.join(format(ord(c), '08b') for c in text)

def binary_to_whitespace(binary):
    return ''.join('\t' if bit == '1' else ' ' for bit in binary)

def encode_message(secret_message, cover_text_file, output_file):
    with open(cover_text_file, 'r', encoding='utf-8') as f:
        cover_text = f.read()

    binary_secret = text_to_binary(secret_message) + '00000000'  
    hidden_whitespace = binary_to_whitespace(binary_secret)

    stego_text = cover_text.rstrip() + hidden_whitespace

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(stego_text)

    print(f"Message successfully hidden in: {output_file}")

if __name__ == "__main__":
    import sys
    if len(sys.argv) == 4:
        encode_message(sys.argv[1], sys.argv[2], sys.argv[3])


