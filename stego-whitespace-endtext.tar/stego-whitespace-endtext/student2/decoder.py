def whitespace_to_binary(whitespace):
    return ''.join('1' if char == '\t' else '0' for char in whitespace if char in [' ', '\t'])

def binary_to_text(binary):
    chars = []
    for i in range(0, len(binary), 8):
        byte = binary[i:i+8]
        if byte == '00000000':
            break
        chars.append(chr(int(byte, 2)))
    return ''.join(chars)

def decode_message(stego_file):
    with open(stego_file, 'r', encoding='utf-8') as f:
        content = f.read()

    trailing_whitespace = ''
    for c in reversed(content):
        if c in [' ', '\t']:
            trailing_whitespace = c + trailing_whitespace
        else:
            break

    binary = whitespace_to_binary(trailing_whitespace)
    message = binary_to_text(binary)
    print("Message:")
    print(message)

if __name__ == "__main__":
    import sys
    if len(sys.argv) == 2:
        decode_message(sys.argv[1])


